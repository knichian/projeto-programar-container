// https://github.com/DanielMelloo/CodeEz


// $(document).ready(function() { 
//   window.location.href='#roadMapIndex';
//   });
// ============ //
// Copiar Texto //
// ============ //






// import {EditorState} from "@codemirror/state"
// import {EditorView, keymap} from "@codemirror/view"
// import {defaultKeymap} from "@codemirror/commands"

// let codeEdit = document.getElementById("codeEdit")
// let arb = codeEdit.textContent

// let editor = CodeMirror.fromTextArea(codeEdit, {
//     value: "function myScript(){return 100;}\n",
//     lineNumbers: true,
//     mode: "text/x-csrc",  // Defina o modo de sintaxe apropriado para C
//     theme: "dracula",  // Escolha o tema do editor
//     autoIndent: true, // Ativa a indentação automática
//     indentUnit: 4,
//     autofocus: true,
//     autoCloseBrackets: true,
// });
// editor.setSize("auto", "auto");

// window.addEventListener("resize", function() {
//     editor.setSize("auto", "auto");
// });

